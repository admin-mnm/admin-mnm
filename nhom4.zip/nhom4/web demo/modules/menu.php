
<div class="menu">
    	<ul>
        	<li><a href="index.php?xem=trangchu">Trang Chủ</a></li>
            <li><a href="index.php?xem=huongdan">Hướng Dẫn Mua Hàng</a></li>
            <li><a href="index.php?xem=thanhtoan">Đăng Nhập</a></li>
             <li><a href="index.php?xem=dangky">Đăng Ký</a></li>
                <li><a href="index.php?xem=tintuc">Tin Tức</a></li>
                <li><a href="index.php?xem=video">Video</a></li>
            <li><a href="index.php?xem=contact">Thông Tin Liên Hệ</a></li>         
            <li><a href="index.php?xem=cart">Giỏ Hàng <img src="image/14085970186309_icon-giao-hang.png" width="20" height="25" /></a></li>			<form action="index.php?xem=ketqua" method="post">
       		<p style="line-height:40px;padding-top:10px;">
            	<input type="text" name="search_query" size="15" style="float:left" /><input type="submit" name="search" value="Tìm kiếm" />
                 
            </p>
            </form>
        </ul>
    </div>