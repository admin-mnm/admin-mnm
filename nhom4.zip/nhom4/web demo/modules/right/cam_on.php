<div class="content_right" style="width:100%;">
	<p align="center" style="margin-top:200px;"><b>Cảm ơn bạn đã đặt hàng </b>chúng tôi sẽ giao hàng cho bạn trong vòng <b>3 ngày</b>.</p>
    <p style="margin-top:50px;" align="right"><a href="index.php">Tiếp tục mua hàng</a></p>
</div>