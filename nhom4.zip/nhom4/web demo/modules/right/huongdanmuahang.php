<h1 align="center">Huong dan mua hang</h1>
<div class="content_right" style="width:100%;">
	<img src="image/huongdanmuahang.jpg" width="100%" height="700px">
</div>
