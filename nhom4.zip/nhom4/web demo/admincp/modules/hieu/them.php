<form action="modules/hieu/xuly.php" method="post">
<table width="200" border="1">
  <tr>
    <td colspan="2">Thêm hiệu</td>
  </tr>
  <tr>
    <td>Hiệu</td>
    <td>
    <input type="text" name="hieu" id="hieu"></td>
  </tr>
  <tr>
    <td colspan="2">
    <input type="submit" name="them" value="Thêm">    </td>
  </tr>
</table>
</form>



