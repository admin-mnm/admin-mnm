  <div class="menu">
    	<ul>
        	<li><a href="index.php?quanly=loai&ac=them">Quản lí loại hàng</a></li>
            <li><a href="index.php?quanly=hieu&ac=them">Quản lí nhà sản xuất</a></li>
           
            <li><a href="index.php?quanly=sanpham&ac=them">Quản lí sản phẫm</a></li>
             <li><a href="index.php?quanly=donhang&ac=lietke">Quản lí đơn hàng</a></li>
              <li><a href="index.php?quanly=tintuc&ac=them">Quản lí tin tức</a></li>	
                 <li><a href="index.php?quanly=video&ac=them">Quản lí video</a></li>
          
        </ul>
    </div>